<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            \Database\Seeders\CreateDefaultRoleSeeder::class,
            \Database\Seeders\CreateDefaultAdminSeeder::class,
            \Database\Seeders\CreateDefaultSettingsSeeder::class,
            \Database\Seeders\CreateDefaultZodiacSignsSeeder::class,
            \Database\Seeders\CreateDefaultHoroscopeSeeder::class,
        ]);

        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
