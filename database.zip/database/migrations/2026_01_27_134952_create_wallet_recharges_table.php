<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('wallet_recharges', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('wallet_id');

            $table->decimal('amount', 12, 2);

            $table->decimal('balance_before', 12, 2);
            $table->decimal('balance_after', 12, 2);

            $table->enum('payment_method', ['upi','card','netbanking']);

            $table->string('gateway_txn_id')->nullable();

            $table->timestamp('recharged_at');

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('wallet_id')->references('id')->on('wallets')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wallet_recharges');
    }
};